IoTHTR.jar may be run anywhere
IoTHTR.jar requires a .txt file called readings.txt to be in the same directory
IoTHTR.jar can only read one readings.txt file at a time

To run a test file, rename any of the included txt files:
 readings_crossing.txt
 readings_fast.txt
 ...

to: readings.txt

Then run IoTHTR.jar (Java 1.8+ is required)

The login details are
Username: admin
Password: password